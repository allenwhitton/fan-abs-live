FAN ABS LIVE PWA
================
1. Upload this folder to any HTTPS static website host.
2. Open the site in Chrome on your Android phone.
3. Chrome menu -> Install app (or Add to Home screen).

The service worker provides app-style installation and caches the app shell.
MLB API requests remain live.

This is a fan-only app and does not send challenges to MLB or affect games.
